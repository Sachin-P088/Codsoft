package com.example.quoteofthedayapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView quoteTextView;
    private Button getQuoteButton;

    private String[] quotes = {
            "The best way to predict the future is to create it.",
            "Success is not the key to happiness. Happiness is the key to success.",
            "Life is 10% what happens to us and 90% how we react to it.",
            "The only way to do great work is to love what you do.",
            "If you can dream it, you can achieve it.",
            "Believe you can and you're halfway there."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        quoteTextView = findViewById(R.id.quoteTextView);
        getQuoteButton = findViewById(R.id.getQuoteButton);

        getQuoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayRandomQuote();
            }
        });
    }

    private void displayRandomQuote() {
        Random random = new Random();
        int randomIndex = random.nextInt(quotes.length);
        String randomQuote = quotes[randomIndex];
        quoteTextView.setText(randomQuote);
    }
}